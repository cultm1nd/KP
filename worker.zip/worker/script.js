//slider
var img = document.getElementById('img');
var slides = ['./img/index.png', './img/sl1.png', './img/sl2.png'];
var Start = 0;
function slider() {
  if (Start < slides.length) {
    Start = Start + 1;
  }
  else {
    Start = 1;
  }
  img.innerHTML = "<img src=" + slides[Start - 1] + " width='400px' height='400px' >";
}
setInterval(slider, 2300);